-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Jan 17, 2024 at 06:34 AM
-- Server version: 10.4.28-MariaDB
-- PHP Version: 8.2.4

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `data_bus`
--

-- --------------------------------------------------------

--
-- Table structure for table `admin`
--

CREATE TABLE `admin` (
  `id` int(11) NOT NULL,
  `nama` varchar(50) NOT NULL,
  `username` varchar(50) NOT NULL,
  `password` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

--
-- Dumping data for table `admin`
--

INSERT INTO `admin` (`id`, `nama`, `username`, `password`) VALUES
(2, 'admin', 'admin', 'admin'),
(3, 'rian', 'rian', 'rian'),
(12, 'natasa', 'natasa', 'natasa'),
(14, 'aisa', 'aisa', 'aisa'),
(16, 'Cynthia Halizah', 'cynthia', 'cynthia123'),
(17, 'Aisyah Arfani', 'aisyah', 'aisyah123'),
(18, 'Muhammad Rian Mizard', 'rian', 'rian'),
(19, 'fikti', 'fikti123', 'fikti123'),
(21, 'aisyah arfani', 'arfani123', 'arfani123'),
(23, 'cynthia', 'cintia', 'cintia123'),
(24, 'fikti02', 'fikti01', 'fikti01');

-- --------------------------------------------------------

--
-- Table structure for table `harga`
--

CREATE TABLE `harga` (
  `id` int(11) NOT NULL,
  `status` varchar(50) NOT NULL,
  `kelas` varchar(20) NOT NULL,
  `harga` varchar(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

--
-- Dumping data for table `harga`
--

INSERT INTO `harga` (`id`, `status`, `kelas`, `harga`) VALUES
(1, 'berdiri', 'dewasa', '3000'),
(2, 'umum', 'anak', '2000'),
(3, 'disabilitas', 'dewasa', '5000'),
(4, 'ibuhamil_lansia', 'ekonomi', '3000');

-- --------------------------------------------------------

--
-- Table structure for table `penumpang`
--

CREATE TABLE `penumpang` (
  `id` varchar(50) NOT NULL,
  `nama` varchar(50) NOT NULL,
  `alamat` varchar(100) NOT NULL,
  `awal` varchar(50) NOT NULL,
  `tujuan` varchar(50) NOT NULL,
  `berangkat` varchar(50) NOT NULL,
  `tiba` varchar(50) NOT NULL,
  `tanggal` varchar(50) NOT NULL,
  `kereta` varchar(50) NOT NULL,
  `gerbong` varchar(50) NOT NULL,
  `dewasa` varchar(50) NOT NULL,
  `anak` varchar(50) NOT NULL,
  `total` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

--
-- Dumping data for table `penumpang`
--

INSERT INTO `penumpang` (`id`, `nama`, `alamat`, `awal`, `tujuan`, `berangkat`, `tiba`, `tanggal`, `kereta`, `gerbong`, `dewasa`, `anak`, `total`) VALUES
('PENUMPANG1', 'Rian', 'Martubung', 'Belawan', 'Martubung', '06.00 WIB', '06.20 WIB', 'Tue Jan 16 16:19:11 ICT 2024', 'Trans Metro Deli', 'Duduk', '2', '0', 'Rp. 10000'),
('PENUMPANG2', 'Aisyah', 'Mabar', 'Belawan', 'Mabar', '06.10 WIB', '06.50 WIB', 'Tue Jan 16 16:19:44 ICT 2024', 'Trans Metro Deli', 'Duduk', '2', '0', 'Rp. 10000'),
('PENUMPANG3', 'Arfani', 'mabar', 'Belawan', 'Mabar', '07.30 WIB', '08.10', 'Tue Jan 16 16:29:03 ICT 2024', 'Bus Kota', 'Duduk', '2', '0', 'Rp. 10000'),
('PENUMPANG4', 'natasya', 'martubung', 'Belawan', 'Martubung', '06.00 WIB', '06.20 WIB', 'Tue Jan 16 16:31:51 ICT 2024', 'Trans Metro Deli', 'Duduk', '2', '0', 'Rp. 10000'),
('PENUMPANG5', 'cynthia', 'denai', 'Belawan', 'Martubung', '07.00 WIB', '07.40 WIB', 'Tue Jan 16 16:33:22 ICT 2024', 'Bus Kota', 'Duduk', '2', '0', 'Rp. 10000'),
('PENUMPANG6', 'cintia', 'medan', 'Belawan', 'UMSU', '06.15 WIB', '07.10 WIB', 'Tue Jan 16 17:30:52 ICT 2024', 'Trans Metro Deli', 'Duduk', '2', '0', 'Rp. 10000'),
('PENUMPANG7', 'natasya', 'martubung', 'Belawan', 'Martubung', '07.00 WIB', '07.40 WIB', 'Wed Jan 17 10:58:28 ICT 2024', 'Bus Kota', 'Duduk', '2', '0', 'Rp. 10000'),
('PENUMPANG8', 'wahyu', 'belawan', 'Belawan', 'Martubung', '07.00 WIB', '07.40 WIB', 'Wed Jan 17 11:58:04 ICT 2024', 'Bus Kota', 'Duduk', '2', '0', 'Rp. 10000'),
('PENUMPANG9', 'fikti', 'umsu', 'Belawan', 'Martubung', '07.00 WIB', '07.40 WIB', 'Wed Jan 17 12:10:12 ICT 2024', 'Bus Kota', 'Duduk', '2', '0', 'Rp. 10000');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `admin`
--
ALTER TABLE `admin`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `harga`
--
ALTER TABLE `harga`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `penumpang`
--
ALTER TABLE `penumpang`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `admin`
--
ALTER TABLE `admin`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=25;

--
-- AUTO_INCREMENT for table `harga`
--
ALTER TABLE `harga`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
