/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package tiket;
import net.sf.jasperreports.engine.JasperCompileManager;
/**
 *
 * @author rianmizard
 */
public class CompileReport {
    public static void main(String[] args) {
        try {
            // Path menuju file JRXML (contoh: src/report/Tiket_New.jrxml)
            String jrxmlFilePath = "src/report/Tiket_New.jrxml";

            // Path tempat menyimpan file Jasper (hasil kompilasi)
            String jasperFilePath = "src/report/Tiket_New.jasper";

            // Kompilasi JRXML ke Jasper
            JasperCompileManager.compileReportToFile(jrxmlFilePath, jasperFilePath);

            System.out.println("Kompilasi berhasil.");
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}
